import { NgModule } from '@angular/core';
import {AboutComponent} from './about.component';
 

@NgModule({
  declarations: [
    AboutComponent
  ],
   
  providers: []
})
export class AboutModule { }
