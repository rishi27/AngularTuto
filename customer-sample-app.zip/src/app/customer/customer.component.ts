import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({ 
  selector: 'cm-orders',
  templateUrl: './customer.component.html'
})
export class CustomerComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }

}

